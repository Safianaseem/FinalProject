import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, ScrollView } from 'react-native';

export default function OrderConfirmationScreen({ navigation, route }) {
  const { orderSummary } = route.params || {};

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Image
        source={{ uri: 'https://cdn-icons-png.flaticon.com/512/845/845646.png' }}
        style={styles.image}
      />
      <Text style={styles.title}>Thank You!</Text>
      <Text style={styles.subtitle}>Your order has been placed successfully.</Text>

      {orderSummary ? (
        <View style={styles.summaryBox}>
          <Text style={styles.summaryTitle}>Order Summary</Text>
          <Text style={styles.detailText}><Text style={styles.label}>Name:</Text> {orderSummary.name}</Text>
          <Text style={styles.detailText}><Text style={styles.label}>Address:</Text> {orderSummary.address}</Text>
          <Text style={styles.detailText}><Text style={styles.label}>Phone:</Text> {orderSummary.phone}</Text>
          <Text style={styles.detailText}><Text style={styles.label}>Payment:</Text> {orderSummary.paymentMethod}</Text>
          <Text style={styles.detailText}><Text style={styles.label}>Total:</Text> ${orderSummary.total.toFixed(2)}</Text>
        </View>
      ) : (
        <Text style={styles.missingText}>No order details available.</Text>
      )}

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Home')}
      >
        <Text style={styles.buttonText}>Back to Home</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 24,
    alignItems: 'center',
    backgroundColor: '#FDFDFD',
    flexGrow: 1,
  },
  image: {
    width: 100,
    height: 100,
    marginBottom: 30,
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#007AFF',
  },
  subtitle: {
    fontSize: 16,
    color: '#333',
    textAlign: 'center',
    marginBottom: 20,
  },
  summaryBox: {
    backgroundColor: '#fff',
    width: '100%',
    borderRadius: 12,
    padding: 20,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 5,
    elevation: 2,
    marginBottom: 30,
  },
  summaryTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
    color: '#007AFF',
  },
  detailText: {
    fontSize: 15,
    color: '#333',
    marginBottom: 6,
  },
  label: {
    fontWeight: 'bold',
  },
  missingText: {
    fontSize: 14,
    color: '#999',
    marginBottom: 30,
  },
  button: {
    backgroundColor: '#007AFF',
    paddingVertical: 14,
    paddingHorizontal: 30,
    borderRadius: 8,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});
