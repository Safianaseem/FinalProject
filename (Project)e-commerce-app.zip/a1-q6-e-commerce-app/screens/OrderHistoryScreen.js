import React from 'react';
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  ScrollView,
} from 'react-native';

export default function OrderHistoryScreen({ route }) {
  const { orders } = route.params;

  const renderOrder = ({ item }) => (
    <View style={styles.card}>
      <Text style={styles.date}>Date: {item.date}</Text>
      <Text>Total: {item.total}</Text>
      <Text>Payment: {item.payment}</Text>
      <Text>Status: {item.status}</Text>
      <Text style={styles.itemHeader}>Items:</Text>
      {item.items.map((product, index) => (
        <Text key={index} style={styles.itemText}>
          • {product.name} x{product.quantity}
        </Text>
      ))}
    </View>
  );

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.header}>Order History</Text>
      {orders.length === 0 ? (
        <Text style={styles.noOrders}>No orders yet.</Text>
      ) : (
        <FlatList
          data={orders}
          renderItem={renderOrder}
          keyExtractor={(item) => item.id}
          contentContainerStyle={{ paddingBottom: 30 }}
        />
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#FDFDFD',
    flexGrow: 1,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#333',
  },
  noOrders: {
    textAlign: 'center',
    marginTop: 50,
    fontSize: 16,
    color: '#666',
  },
  card: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 5,
    elevation: 2,
  },
  date: {
    fontWeight: 'bold',
    marginBottom: 4,
  },
  itemHeader: {
    marginTop: 10,
    fontWeight: 'bold',
  },
  itemText: {
    marginLeft: 10,
    color: '#555',
  },
});
