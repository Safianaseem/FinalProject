import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  FlatList,
  StyleSheet,
  Image,
  TouchableOpacity,
  ScrollView,
} from 'react-native';

const categories = ['All', 'Electronics', 'Clothes', 'Shoes', 'Beauty', 'Books'];

const products = [
  {
    id: '1',
    name: 'Smartphone',
    price: '$299',
    category: 'Electronics',
    image: 'https://www.techadvisor.com/wp-content/uploads/2025/04/best-phones-2025.jpg?quality=50&strip=all',
    description: 'A high-end smartphone with amazing features.',
  },
  {
    id: '2',
    name: 'Running Shoes',
    price: '$89',
    category: 'Shoes',
    image: 'https://sportify.pro/cdn/shop/files/fashion-breathable-walking-running-shoes-for-women-sf1735-002.png?v=1698180761',
    description: 'Comfortable and breathable running shoes for every step.',
  },
  {
    id: '3',
    name: 'T-shirt',
    price: '$15',
    category: 'Clothes',
    image: 'https://cdn.pixabay.com/photo/2016/10/02/22/17/t-shirt-1710578_960_720.jpg',
    description: 'A soft cotton t-shirt available in various colors.',
  },
  {
    id: '4',
    name: 'Face Cream',
    price: '$25',
    category: 'Beauty',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnSh7Vp8z3Pxg1kod9O9818MoGOM0pO9EQEg&s',
    description: 'A nourishing cream to keep your skin soft and smooth.',
  },
  {
    id: '5',
    name: 'Laptop',
    price: '$799',
    category: 'Electronics',
    image: 'https://www.computronix.com.pk/wp-content/uploads/2024/01/image-removebg-preview-10.png',
    description: 'A powerful laptop with high-performance specs.',
  },
  {
    id: '6',
    name: 'Novel Book',
    price: '$12',
    category: 'Books',
    image: 'https://cdn.pixabay.com/photo/2015/09/05/21/51/reading-925589_960_720.jpg',
    description: 'An exciting novel that will keep you engaged for hours.',
  },
  {
    id: '7',
    name: 'Headphones',
    price: '$59',
    category: 'Electronics',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTjHS1rhqO6WDzi-oE7i7lO77dllcYFbhDIQQ&s',
    description: 'Noise-cancelling headphones for immersive sound.',
  },
  {
    id: '8',
    name: 'Leather Jacket',
    price: '$120',
    category: 'Clothes',
    image: 'https://www.acecart.pk/cdn/shop/files/8-1_b215a744-2201-4f3a-ad3b-78b7faeedfa2.jpg?v=1713611297',
    description: 'Stylish leather jacket for a bold look.',
  },
  {
    id: '9',
    name: 'Sneakers',
    price: '$95',
    category: 'Shoes',
    image: 'https://cdn.thewirecutter.com/wp-content/media/2024/05/white-sneaker-2048px-9320.jpg?auto=webp&quality=75&width=1024',
    description: 'Trendy sneakers for casual wear.',
  },
  {
    id: '10',
    name: 'Foundation',
    price: '$35',
    category: 'Beauty',
    image: 'https://i5.walmartimages.com/seo/Maybelline-Fit-Me-Matte-Poreless-Liquid-Oil-Free-Foundation-Makeup-Ivory-1-Count-Packaging-May-Vary_012139ce-0e92-4793-96b3-2bcb3b187e03.ff435253fa9d640a00a2b605890d9c2b.jpeg',
    description: 'Long-lasting foundation with a natural finish.',
  },
  {
    id: '11',
    name: 'Tablet',
    price: '$199',
    category: 'Electronics',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRth4FHgoxD8tpLsEIoE4wqq_hUaSa40dnqwg&s',
    description: 'Lightweight tablet for reading and streaming.',
  },
  {
    id: '12',
    name: 'Cookbook',
    price: '$22',
    category: 'Books',
    image: 'https://cdn.loveandlemons.com/wp-content/uploads/2023/01/cookbook3.jpg',
    description: 'Delicious recipes for every kitchen enthusiast.',
  },
];

export default function HomeScreen({ navigation }) {
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');

  const filteredProducts = products.filter(
    (product) =>
      (selectedCategory === 'All' || product.category === selectedCategory) &&
      product.name.toLowerCase().includes(search.toLowerCase())
  );

  const renderProduct = ({ item }) => (
    <TouchableOpacity onPress={() => navigation.navigate('ProductDetails', { product: item })}>
      <View style={styles.card}>
        <Image source={{ uri: item.image }} style={styles.productImage} />
        <View style={styles.textContainer}>
          <Text style={styles.productName}>{item.name}</Text>
          <Text style={styles.productPrice}>{item.price}</Text>
          <Text style={styles.productDescription}>{item.description}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Header with title and profile icon */}
      <View style={styles.header}>
        <Text style={styles.title}>Home</Text>
        <TouchableOpacity onPress={() => navigation.navigate('Profile')}>
          <Image
            source={{
              uri: 'https://easy-peasy.ai/cdn-cgi/image/quality=80,format=auto,width=700/https://media.easy-peasy.ai/10357f16-cd51-440f-bc72-016612eb320a/603d52f0-1745-4737-bf72-9cf0aaa9947b.png',
            }}
            style={styles.profileIcon}
          />
        </TouchableOpacity>
      </View>

      {/* Search Bar */}
      <View style={styles.searchBar}>
        <TextInput
          placeholder="Search products..."
          style={styles.searchInput}
          value={search}
          onChangeText={setSearch}
        />
      </View>

      {/* Categories */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryScroll}>
        {categories.map((cat) => (
          <TouchableOpacity
            key={cat}
            style={[
              styles.categoryButton,
              selectedCategory === cat && styles.activeCategoryButton,
            ]}
            onPress={() => setSelectedCategory(cat)}
          >
            <Text
              style={
                selectedCategory === cat
                  ? styles.activeCategoryText
                  : styles.categoryText
              }
            >
              {cat}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Product List */}
      <FlatList
        data={filteredProducts}
        keyExtractor={(item) => item.id}
        renderItem={renderProduct}
        numColumns={1}
        contentContainerStyle={styles.productListContainer}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FAFAFA',
    paddingHorizontal: 16,
    paddingTop: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: '700',
    color: '#1A1A1A',
  },
  profileIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  searchBar: {
    backgroundColor: '#EFEFEF',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 16,
  },
  searchInput: {
    fontSize: 16,
  },
  categoryScroll: {
    marginBottom: 20,
  },
  categoryButton: {
    marginRight: 12,
    paddingVertical: 6,
    paddingHorizontal: 14,
    backgroundColor: '#EDEDED',
    borderRadius: 20,
  },
  activeCategoryButton: {
    backgroundColor: '#007AFF',
  },
  categoryText: {
    fontSize: 15,
    color: '#555',
  },
  activeCategoryText: {
    fontSize: 15,
    color: '#fff',
    fontWeight: '600',
  },
  productListContainer: {
    paddingBottom: 80,
  },
  card: {
    flexDirection: 'row',
    backgroundColor: '#FFFFFF',
    borderRadius: 14,
    padding: 12,
    marginBottom: 14,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 1,
  },
  productImage: {
    width: 100,
    height: 100,
    borderRadius: 10,
    marginRight: 12,
  },
  textContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  productName: {
    fontSize: 16,
    fontWeight: '600',
    color: '#222',
    marginBottom: 4,
  },
  productPrice: {
    fontSize: 14,
    color: '#007AFF',
    marginBottom: 4,
  },
  productDescription: {
    fontSize: 12,
    color: '#666',
  },
});
