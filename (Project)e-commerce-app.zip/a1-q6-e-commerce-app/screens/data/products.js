const products = [
  {
    id: '1',
    name: 'Smartphone',
    price: '$299',
    category: 'Electronics',
    description: 'Latest model with high-resolution camera and fast processor.',
    image: 'https://cdn.pixabay.com/photo/2014/09/27/13/44/iphone-464144_960_720.jpg',
  },
  {
    id: '2',
    name: 'Running Shoes',
    price: '$89',
    category: 'Shoes',
    description: 'Comfortable running shoes for daily use.',
    image: 'https://cdn.pixabay.com/photo/2016/11/21/15/46/adidas-1845510_960_720.jpg',
  },
  {
    id: '3',
    name: 'T-shirt',
    price: '$15',
    category: 'Clothes',
    description: 'Soft cotton t-shirt available in multiple sizes.',
    image: 'https://cdn.pixabay.com/photo/2016/10/02/22/17/t-shirt-1710578_960_720.jpg',
  },
  {
    id: '4',
    name: 'Beauty Cream',
    price: '$25',
    category: 'Beauty',
    description: 'Moisturizing beauty cream for glowing skin.',
    image: 'https://cdn.pixabay.com/photo/2017/01/07/17/43/cosmetics-1961466_960_720.jpg',
  },
  {
    id: '5',
    name: 'Book: Learn JavaScript',
    price: '$18',
    category: 'Books',
    description: 'Great for beginners and intermediate developers.',
    image: 'https://cdn.pixabay.com/photo/2016/06/20/05/35/javascript-1468652_960_720.png',
  },
];

export default products;
