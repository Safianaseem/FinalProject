import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  Image,
  TouchableOpacity,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

export default function ProfileScreen() {
  const [darkMode, setDarkMode] = useState(false);

  const toggleTheme = () => setDarkMode((prev) => !prev);

  const user = {
    name: 'Safia Moosa',
    email: 'safia@example.com',
    image: 'https://easy-peasy.ai/cdn-cgi/image/quality=80,format=auto,width=700/https://media.easy-peasy.ai/10357f16-cd51-440f-bc72-016612eb320a/603d52f0-1745-4737-bf72-9cf0aaa9947b.png',
  };

  const themeStyles = darkMode ? darkTheme : lightTheme;

  return (
    <View style={[styles.container, themeStyles.container]}>
      <View style={styles.profileContainer}>
        <Image source={{ uri: user.image }} style={styles.avatar} />
        <Text style={[styles.name, themeStyles.text]}>{user.name}</Text>
        <Text style={[styles.email, themeStyles.text]}>{user.email}</Text>
      </View>

      <View style={styles.optionsContainer}>
        <View style={styles.optionRow}>
          <Icon name="moon-outline" size={22} color={darkMode ? '#fff' : '#333'} />
          <Text style={[styles.optionText, themeStyles.text]}>Dark Mode</Text>
          <Switch value={darkMode} onValueChange={toggleTheme} />
        </View>

        <TouchableOpacity style={styles.optionRow}>
          <Icon name="person-outline" size={22} color={darkMode ? '#fff' : '#333'} />
          <Text style={[styles.optionText, themeStyles.text]}>Edit Profile</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.optionRow}>
          <Icon name="settings-outline" size={22} color={darkMode ? '#fff' : '#333'} />
          <Text style={[styles.optionText, themeStyles.text]}>App Settings</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.optionRow}>
          <Icon name="log-out-outline" size={22} color="#FF3B30" />
          <Text style={[styles.optionText, { color: '#FF3B30' }]}>Logout</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const lightTheme = StyleSheet.create({
  container: {
    backgroundColor: '#FDFDFD',
  },
  text: {
    color: '#333',
  },
});

const darkTheme = StyleSheet.create({
  container: {
    backgroundColor: '#1c1c1e',
  },
  text: {
    color: '#fff',
  },
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  profileContainer: {
    alignItems: 'center',
    marginTop: 30,
    marginBottom: 40,
  },
  avatar: {
    width: 90,
    height: 90,
    borderRadius: 45,
    marginBottom: 12,
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  email: {
    fontSize: 14,
    color: '#666',
  },
  optionsContainer: {
    gap: 20,
  },
  optionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingVertical: 10,
  },
  optionText: {
    fontSize: 16,
    flex: 1,
  },
});
