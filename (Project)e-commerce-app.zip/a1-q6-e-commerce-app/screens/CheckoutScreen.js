import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  Alert,
  ActivityIndicator,
} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';

export default function CheckoutScreen({ navigation, route }) {
  const [cartItems, setCartItems] = useState(route.params?.cartItems || []);
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [selectedPayment, setSelectedPayment] = useState('Credit Card');
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);

  const paymentMethods = ['Credit Card', 'PayPal', 'Cash on Delivery'];

  const subtotal = cartItems.reduce(
    (sum, item) => sum + parseFloat(item.price.replace('$', '')) * item.quantity,
    0
  );
  const shippingFee = subtotal > 0 ? 10 : 0;
  const total = subtotal + shippingFee;

  const handlePlaceOrder = () => {
    if (!name || !address || !phone) {
      Alert.alert('Missing Info', 'Please fill out all shipping details.');
      return;
    }

    setIsPlacingOrder(true);

    setTimeout(() => {
      const orderSummary = {
        name,
        address,
        phone,
        paymentMethod: selectedPayment,
        cartItems,
        subtotal,
        shippingFee,
        total,
      };

      setIsPlacingOrder(false);
      setCartItems([]); // Clear cart
      navigation.replace('OrderConfirmation', { orderSummary });
    }, 1500);
  };

  return (
    <ScrollView contentContainerStyle={styles.container} showsVerticalScrollIndicator={false}>
      <Text style={styles.header}>Checkout</Text>

      {/* Shipping Details */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Shipping Details</Text>
        <TextInput
          style={styles.input}
          placeholder="Full Name"
          value={name}
          onChangeText={setName}
        />
        <TextInput
          style={styles.input}
          placeholder="Address"
          value={address}
          onChangeText={setAddress}
        />
        <TextInput
          style={styles.input}
          placeholder="Phone Number"
          value={phone}
          keyboardType="phone-pad"
          onChangeText={setPhone}
        />
      </View>

      {/* Payment Methods */}
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Payment Method</Text>
        {paymentMethods.map((method) => (
          <TouchableOpacity
            key={method}
            style={styles.radioContainer}
            onPress={() => setSelectedPayment(method)}
          >
            <Icon
              name={selectedPayment === method ? 'radio-button-on' : 'radio-button-off'}
              size={20}
              color="#007AFF"
              style={{ marginRight: 8 }}
            />
            <Text style={styles.radioText}>{method}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Order Summary */}
      <View style={styles.summaryCard}>
        <Text style={styles.summaryText}>Subtotal: ${subtotal.toFixed(2)}</Text>
        <Text style={styles.summaryText}>Shipping: ${shippingFee.toFixed(2)}</Text>
        <View style={styles.line} />
        <Text style={styles.totalText}>Total: ${total.toFixed(2)}</Text>
        <TouchableOpacity
          style={styles.placeOrderButton}
          onPress={handlePlaceOrder}
          disabled={isPlacingOrder}
        >
          {isPlacingOrder ? (
            <ActivityIndicator color="#fff" />
          ) : (
            <Text style={styles.placeOrderText}>Place Order</Text>
          )}
        </TouchableOpacity>
      </View>

      {/* Navigation Buttons */}
      <TouchableOpacity
        style={styles.navButton}
        onPress={() => navigation.navigate('ProfileSettings')}
      >
        <Text style={styles.navButtonText}>Go to Profile & Settings</Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.navButton}
        onPress={() => navigation.navigate('OrderHistory')}
      >
        <Text style={styles.navButtonText}>Go to Order History</Text>
      </TouchableOpacity>

      {/* Profile Card */}
      <View style={styles.profileCard}>
        <Image
          source={{ uri: 'https://placeimg.com/100/100/people' }}
          style={styles.profileImage}
        />
        <Text style={styles.profileName}>Jane Doe</Text>
        <Text style={styles.profileDetails}>Email: janedoe@example.com</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    backgroundColor: '#FDFDFD',
    flexGrow: 1,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
    textAlign: 'center',
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 10,
    color: '#333',
  },
  input: {
    backgroundColor: '#EFEFEF',
    borderRadius: 10,
    padding: 12,
    fontSize: 16,
    marginBottom: 10,
  },
  radioContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
  },
  radioText: {
    fontSize: 16,
    color: '#333',
  },
  summaryCard: {
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 5,
    elevation: 2,
    marginTop: 10,
  },
  summaryText: {
    fontSize: 16,
    color: '#555',
    marginBottom: 6,
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#000',
    marginTop: 10,
    marginBottom: 16,
  },
  line: {
    height: 1,
    backgroundColor: '#DDD',
    marginVertical: 8,
  },
  placeOrderButton: {
    backgroundColor: '#007AFF',
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeOrderText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  navButton: {
    backgroundColor: '#FF5F5F',
    paddingVertical: 12,
    borderRadius: 10,
    marginBottom: 16,
    alignItems: 'center',
  },
  navButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
  profileCard: {
    marginTop: 24,
    padding: 16,
    backgroundColor: '#fff',
    borderRadius: 10,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  profileImage: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 12,
  },
  profileName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  profileDetails: {
    fontSize: 14,
    color: '#555',
  },
});
