import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  Alert,
  TouchableOpacity,
  ActivityIndicator,
  StatusBar,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import Icon from 'react-native-vector-icons/MaterialIcons';

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [storedEmail, setStoredEmail] = useState('');
  const [storedPassword, setStoredPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [showPassword, setShowPassword] = useState(false); // For toggling password visibility

  // Fetch stored data (email and password) from AsyncStorage
  useEffect(() => {
    const fetchStoredData = async () => {
      const savedEmail = await AsyncStorage.getItem('userEmail');
      const savedPassword = await AsyncStorage.getItem('userPassword');
      setStoredEmail(savedEmail || '');
      setStoredPassword(savedPassword || '');
    };
    fetchStoredData();
  }, []);

  // Handle login action
  const handleLogin = () => {
    if (!email || !password) {
      setErrorMsg('Please fill all fields');
      return;
    }

    if (email !== storedEmail || password !== storedPassword) {
      setErrorMsg('Invalid email or password');
      return;
    }

    setErrorMsg('');
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      Alert.alert('Welcome', 'You are logged in!');
      navigation.navigate('Home');
    }, 1000);
  };

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#0D47A1" barStyle="light-content" />
      <Image
        source={{ uri: 'https://cdn-icons-png.flaticon.com/512/747/747376.png' }}
        style={styles.logo}
      />
      <Text style={styles.title}>Login</Text>

      {/* Email Input Field */}
      <View style={styles.inputContainer}>
        <Icon name="email" size={20} color="#555" style={styles.icon} />
        <TextInput
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          style={styles.input}
          keyboardType="email-address"
          autoCapitalize="none"
        />
      </View>

      {/* Password Input Field with Show/Hide Option */}
      <View style={styles.inputContainer}>
        <Icon name="lock" size={20} color="#555" style={styles.icon} />
        <TextInput
          placeholder="Password"
          value={password}
          onChangeText={setPassword}
          style={styles.input}
          secureTextEntry={!showPassword} // Toggle visibility based on state
        />
        <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
          <Icon
            name={showPassword ? "visibility-off" : "visibility"} // Change icon based on visibility state
            size={24}
            color="#555"
            style={styles.eyeIcon}
          />
        </TouchableOpacity>
      </View>

      {/* Error Message */}
      {errorMsg ? <Text style={styles.error}>{errorMsg}</Text> : null}

      {/* Login Button */}
      <TouchableOpacity
        style={[styles.button, loading && styles.disabledButton]}
        onPress={handleLogin}
        disabled={loading}
      >
        {loading ? (
          <ActivityIndicator size="small" color="#FFF" />
        ) : (
          <Text style={styles.buttonText}>Login</Text>
        )}
      </TouchableOpacity>

      {/* Navigate to Signup Screen */}
      <TouchableOpacity onPress={() => navigation.navigate('Signup')} style={styles.link}>
        <Text style={styles.linkText}>Don't have an account? Sign up</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', paddingHorizontal: 24, backgroundColor: '#E3F2FD' },
  logo: { width: 100, height: 100, alignSelf: 'center', marginBottom: 20 },
  title: { fontSize: 28, fontWeight: 'bold', marginBottom: 24, textAlign: 'center', color: '#0D47A1' },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF',
    borderRadius: 10,
    paddingHorizontal: 10,
    marginBottom: 10,
    borderWidth: 1,
    borderColor: '#BBDEFB',
  },
  icon: { marginRight: 10 },
  input: { flex: 1, paddingVertical: 12 },
  button: {
    backgroundColor: '#0D47A1',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 10,
  },
  disabledButton: { opacity: 0.6 },
  buttonText: { color: '#FFF', fontSize: 16, fontWeight: 'bold' },
  link: { marginTop: 20, alignItems: 'center' },
  linkText: { color: '#0D47A1', fontSize: 14 },
  error: { color: 'red', marginTop: 5, marginBottom: 10, marginLeft: 5 },
  eyeIcon: { marginLeft: 10 },
});
